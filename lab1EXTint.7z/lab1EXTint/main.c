/*
 * TUSUR. FB
 * FILE: main.c
 * compiler : gcc Keil uvision 5
 * Last modified: 13.10.2020
 * Support mail : a.s.khlebnikov@yandex.ru (Khlebnikov A.S.)
 * Description : External Interrupt with NVIC lab1
 
 */



#include "MDR32Fx.h" // Device header
#include "MDR32F9Qx_port.h" // Keil::Drivers:PORT
#include "system_MDR32F9Qx.h" // Keil::Device:Startup
#include "MDR32F9Qx_rst_clk.h" // Keil::Drivers:RST_CLK


PORT_InitTypeDef PORT_InitStructure;
int main(void)
{
RST_CLK_PCLKcmd(RST_CLK_PCLK_PORTA |
RST_CLK_PCLK_PORTB | RST_CLK_PCLK_PORTC |
RST_CLK_PCLK_PORTE, ENABLE);

SCB->VTOR = 0x08000000;
PORT_InitStructure.PORT_Pin = (PORT_Pin_2);
PORT_InitStructure.PORT_OE = PORT_OE_OUT;
PORT_InitStructure.PORT_FUNC = PORT_FUNC_PORT;
PORT_InitStructure.PORT_MODE = PORT_MODE_DIGITAL;
PORT_InitStructure.PORT_SPEED = PORT_SPEED_SLOW;
PORT_Init(MDR_PORTC, &PORT_InitStructure);

PORT_InitStructure.PORT_Pin = (PORT_Pin_10);
PORT_InitStructure.PORT_OE = PORT_OE_IN;
PORT_InitStructure.PORT_FUNC = PORT_FUNC_PORT;
PORT_InitStructure.PORT_MODE = PORT_MODE_DIGITAL;
PORT_InitStructure.PORT_SPEED = PORT_SPEED_MAXFAST;
PORT_InitStructure.PORT_PULL_UP = PORT_PULL_UP_OFF;
PORT_InitStructure.PORT_PULL_DOWN = PORT_PULL_DOWN_ON;
PORT_Init(MDR_PORTB, &PORT_InitStructure);

PORT_InitStructure.PORT_Pin = (PORT_Pin_10);
PORT_InitStructure.PORT_OE = PORT_OE_IN;
PORT_InitStructure.PORT_FUNC = PORT_FUNC_ALTER;
PORT_InitStructure.PORT_MODE = PORT_MODE_DIGITAL;
PORT_InitStructure.PORT_SPEED = PORT_SPEED_SLOW;
PORT_InitStructure.PORT_PULL_UP = PORT_PULL_UP_OFF;
PORT_InitStructure.PORT_PULL_DOWN = PORT_PULL_DOWN_ON;
PORT_Init(MDR_PORTB, &PORT_InitStructure);

__enable_irq();
NVIC_EnableIRQ(EXT_INT2_IRQn);

while(1){};
}

void EXT_INT2_IRQHandler(void)
{
PORT_SetBits(MDR_PORTC, PORT_Pin_2);

NVIC_ClearPendingIRQ(EXT_INT2_IRQn);
}