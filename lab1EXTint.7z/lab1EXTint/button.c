#include "button.h"
void button_Init(void) 
{
	PORT_InitTypeDef PORT_InitStructure;
	PORT_InitStructure.PORT_OE = PORT_OE_IN;
	PORT_InitStructure.PORT_FUNC = PORT_FUNC_PORT;
	PORT_InitStructure.PORT_MODE = PORT_MODE_DIGITAL;
	PORT_InitStructure.PORT_SPEED = PORT_SPEED_SLOW;
	PORT_InitStructure.PORT_Pin = (PORT_Pin_5);
	PORT_Init(MDR_PORTD, &PORT_InitStructure);
} 
uint8_t button_State(void) {
	return PORT_ReadInputDataBit(MDR_PORTD, PORT_Pin_5);
} 