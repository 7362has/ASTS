#ifndef __BUTTON_H__ 
#define __BUTTON_H__ 
 
#include "type_custom.h" 
 
void button_Init(void); 
uint8_t button_State(void); 
#endif