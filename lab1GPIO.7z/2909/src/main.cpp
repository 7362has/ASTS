/*
 * TUSUR. FB
 * FILE: main.cpp
 * compiler : gcc
 * Last modified: 13.10.2020
 * Support mail : a.s.khlebnikov@yandex.ru (Khlebnikov A.S.)
 * Description : Включение светодиода по нажатию кнопки лабораторная работа 1
 
 */

#include "main.h"
#include <stdlib.h>
#include <stdio.h>
#include <inttypes.h>
#include "mstn_version.h"
#include "mstn_usb.h"
#include "MDR32F9Qx_port.h"
#include "MDR32F9Qx_RST_CLK.h"
#include "MDR32F9Qx_config.h"

#define VD7 PORT_Pin_2//define pin 2  to LED VD7
#define SA4 PORT_Pin_5//define pin 5 to Button SA4

static PORT_InitTypeDef PortInit;

int main(int argc, char *argv[])
{
    const _mstn_version * mstnSdkVersion = NULL;
    const _mstn_version * mstnBootVersion = NULL;
    const _mstn_serial_number * mstnSerialNumber = NULL;
      mstnSdkVersion = MSTN_GetLibVersion();
    mstnBootVersion = MSTN_GetBootloaderVersion();
    mstnSerialNumber = MSTN_GetSerialNumber();
    while(USB_GetStatus() != PERMITTED);
    printf("Hello World!\n");
    printf("Serial Number: %u\n", mstnSerialNumber->serialNumber);
    printf("Bootloader version:   %u.%u.%u\n",
                                                mstnBootVersion->major,
                                                mstnBootVersion->minor,
                                                mstnBootVersion->build);
    printf("MSTN Library version: %u.%u.%u\n",
                                                mstnSdkVersion->major,
                                                mstnSdkVersion->minor,
                                                mstnSdkVersion->build);
        RST_CLK_PCLKcmd(RST_CLK_PCLK_PORTD, ENABLE);//switch on port d clocking
	RST_CLK_PCLKcmd(RST_CLK_PCLK_PORTC, ENABLE);//switch on port c clocking
	//init port D like input
	PortInit.PORT_OE = PORT_OE_IN; // port mode -> input
	PortInit.PORT_FUNC = PORT_FUNC_PORT; // port mode
	PortInit.PORT_MODE = PORT_MODE_DIGITAL; // digital port mode
	PortInit.PORT_SPEED = PORT_SPEED_SLOW;  // choose slow mode for front
	PortInit.PORT_Pin = (SA4); // pin number 5 (PD5) which is connected to SA4 button
	PORT_Init(MDR_PORTD, &PortInit); // init port
	
        // init port C like output
	PortInit.PORT_OE = PORT_OE_OUT; // port mode -> output
	PortInit.PORT_FUNC = PORT_FUNC_PORT; // port mode
	PortInit.PORT_MODE = PORT_MODE_DIGITAL; // digital port mode
	PortInit.PORT_SPEED = PORT_SPEED_SLOW; // choose slow mode for front
	PortInit.PORT_Pin = (VD7); // pin number 2 (PC2) which is connected to VD7 LED
	PORT_Init(MDR_PORTC, &PortInit); // port C init with defined parameters
	PORT_ResetBits(MDR_PORTC, VD7);
    
    while(1)
    {
      if (PORT_ReadInputDataBit(MDR_PORTD, SA4) == 0) // if button pressed
				{
				PORT_SetBits(MDR_PORTC, VD7); // LED on
				}
			else
				{
				PORT_ResetBits(MDR_PORTC, VD7); // LED off
				}
    }
    return EXIT_SUCCESS;
}
